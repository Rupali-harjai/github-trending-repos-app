import React from 'react'

const SingleRepo = () => {
  return (
    <div>SingleRepo</div>
  )
}

export default SingleRepo